package br.pucpr.Coordenador;

import br.pucpr.Matriz;

import java.io.*;
import java.math.*;
import java.util.*;
import java.util.concurrent.Semaphore;

public class Coordenador {


    public static int[] portasCalculadorasS = {5996,5997,5998,5999};
    protected static int nCalculadoras = portasCalculadorasS.length;

    public static Semaphore sync = new Semaphore(0);

    private Random rand = new Random();

    //Arquivos
    private final String pathA, pathB, pathC;


    //Matrizes
    protected static int linha, k, coluna;
    protected static Matriz matrizA, matrizB, matrizC;

    private int[] divComeco, divFim;



    public Coordenador(){
        //Arquivos
        this.pathA = "matrix\\matrixA.txt";
        this.pathB = "matrix\\matrixB.txt";
        this.pathC = "matrix\\matrixC.txt";
    }



    public void CALCULO() throws Exception{

        System.out.println("Processo iniciado");

        //gera matrizes novas caso true
        takeMatrizes(true);

        matrizA = new Matriz(pathA);    //cria uma nova matriz a partir do arquivo
        matrizB = new Matriz(pathB);    //cria uma nova matriz a partir do arquivo

        //atualiza o valor das linhas e colunas
        linha = matrizA.getLinhas();
        k = matrizA.getColunas();
        coluna = matrizB.getColunas();

        //inicializa a matriz C
        matrizC = new Matriz(linha, coluna);

        //divide o que cada Calculadora irá calcular
        divComeco = divisora_inicio();
        divFim = divisora_ultimo();

        System.out.println(Arrays.toString(divComeco));
        System.out.println(Arrays.toString(divFim));

        //deubug ativo
        System.out.println("Criação das novas threads");

//        ia as threads que irão fazer a comunicação com cada calculadora
        for (int i = 0; i < nCalculadoras; i++)
            new ComunicacaoCalculador(portasCalculadorasS[i], divComeco[i], divFim[i]).start();

        //espera por todas concluirem o processo
        sync.acquire(nCalculadoras);

        //Salvar a matriz C em um arquivo
        matrizC.saveMatrix(new BufferedWriter(new FileWriter(new File(pathC))));


        System.out.println("Matriz C escrita");


        System.out.println("Processo encerrado");
    }



    private void takeMatrizes(boolean novas) throws Exception{
        if (novas){
            int valMin = 10;
            int valMax = 100;

            int nRandon = rand.nextInt(200)+400;
            int kRandon = rand.nextInt(200)+400;
            int mRandom = rand.nextInt(200)+400;
//
//            int nRandon = 6;
//            int kRandon = 4;
//            int mRandom = 8;

            matrizA = new Matriz(valMin, valMax, nRandon, kRandon);
            matrizA.saveMatrix(new BufferedWriter(new FileWriter(pathA)));

            matrizB = new Matriz(valMin, valMax, kRandon, mRandom);
            matrizB.saveMatrix(new BufferedWriter(new FileWriter(pathB)));
        }
    }



    //auxiliares

    private int[] divisora_inicio(){
        int[] parts = new int[nCalculadoras];
        for (int i = 0; i < nCalculadoras; i++)
            parts[i] = (i) * (linha * coluna)/nCalculadoras;
        return parts;
    }

    protected int[] divisora_ultimo(){
        int[] parts = new int[nCalculadoras];
        for (int i = 0; i < nCalculadoras; i++)
            parts[i] = ((i+1) * (linha * coluna)/nCalculadoras)-1;
        return parts;
    }

    private void escreverNovaMatrix(int l, int c, BufferedWriter bw) throws Exception{
        bw.write(l + "," + c);
        bw.newLine();
        for (int i = 0; i < l; i++){
            for (int j = 0; j < c; j++)
                bw.append(String.valueOf(randDouble(5, 100, 2))).append(",");
            bw.newLine();
        }
    }

    private double randDouble(int min, int max, int places){
        int randInt = rand.nextInt(max-min)+min;
        BigDecimal bigDecimal = new BigDecimal(Double.toString(randInt + rand.nextDouble()));
        bigDecimal = bigDecimal.setScale(places, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }


}
