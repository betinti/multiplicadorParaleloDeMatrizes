package br.pucpr.Coordenador;

import br.pucpr.Comunicacao;

import java.net.*;

public class ComunicacaoCalculador extends Thread{


    //matriz
    private final int posComeco, posFim;

    //comunicação
    private final int portaCalculador;
    private Socket socket;

    public ComunicacaoCalculador(int portaCalculador, int posComeco, int porFim) throws Exception {
        this.portaCalculador = portaCalculador;
        this.socket = new Socket("localhost", portaCalculador);

        this.posComeco = posComeco;
        this.posFim = porFim;
    }



    @Override
    public void run() {
        try {

            Comunicacao.enviar(Coordenador.matrizA, socket);

//            receber();

            System.out.println(" >> Matriz A enviada");

            Comunicacao.enviar(Coordenador.matrizB, socket);

//            receber();

            System.out.println(" >> Matriz B enviada");

            String bounds = new String(new StringBuilder().append(posComeco).append(",").append(posFim));

            Comunicacao.enviar(bounds, socket);

            System.out.println(" >> Bounds enviados");

            completaMatrixC(Comunicacao.receberString(socket));

            System.out.println(" >> Calculo recebido");

            Coordenador.sync.release();

            System.out.println(" >> terminou");
        } catch (Exception e){
            e.printStackTrace();
        }
    }



    private void completaMatrixC(String data){
        String[] recived = data.split(";");
        int j = 0;
        for (int i = posComeco; i < posFim; i++){
            int[] pos = achaPosicao(i, Coordenador.coluna);
            Coordenador.matrizC.getMatriz()[pos[0]][pos[1]] = toDouble(recived[j++]);
        }
    }


    private int[] achaPosicao(int x, int linhas){
        return new int[]{x/linhas, x%linhas};
    }

    private String preparaMatrix(double[][] matriz){
        StringBuilder sb = new StringBuilder();
        for (double[] linha : matriz){
            for (double coluna : linha)
                sb.append(coluna).append(",");
            sb.append(";");
        }
        return new String(sb);
    }

    private double toDouble(String bruto){
        String[] b = bruto.split(",");
        return (double) Integer.parseInt(b[0]) + (double) Integer.parseInt(b[1])/100;
    }
}
