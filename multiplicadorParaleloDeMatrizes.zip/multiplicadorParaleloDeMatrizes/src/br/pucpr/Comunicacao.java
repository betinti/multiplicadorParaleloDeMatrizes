package br.pucpr;

import java.io.*;
import java.net.*;

public class Comunicacao {

    public static void enviar(Matriz classMatriz, Socket socket) throws Exception{
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        objectOutputStream.writeObject(classMatriz);

    }

    public static void enviar(String data, Socket socket) throws Exception{
        PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
        printWriter.println(data);
        printWriter.flush();
    }

    public static Matriz receberClass(Socket socket) throws Exception{
        return (Matriz) new ObjectInputStream(socket.getInputStream()).readObject();
    }

    public static String receberString(Socket socket) throws Exception{
        return new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine();
    }

}
