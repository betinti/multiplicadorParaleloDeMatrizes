package br.pucpr.Calculador;

import br.pucpr.Comunicacao;
import br.pucpr.Matriz;

import java.net.*;
import java.text.*;
import java.util.Arrays;

public class Calculador {

    private final String nome;

    private final DecimalFormat df;

    private ServerSocket serverSocket;
    private Socket socket;

    private Matriz matrizA, matrizB, matrizC;

    public Calculador(String nome, int portaS) throws Exception{
        this.serverSocket = new ServerSocket(portaS);
        this.nome = nome;
        this.df  = new DecimalFormat("##.00");
    }



    public void CALCULATE() throws Exception{

        System.out.println(nome + ">> Processo iniciado");

        socket = serverSocket.accept();

        matrizA = Comunicacao.receberClass(socket);


        System.out.println(nome + ">> Matriz A recebida");


        matrizB = Comunicacao.receberClass(socket);

        System.out.println(nome + ">> Matriz B recebida");

        matrizC = new Matriz(matrizA.getLinhas(), matrizB.getColunas());


        System.out.println("linhas de c: " + matrizC.getLinhas());
        System.out.println("colunas de c: " + matrizC.getColunas());

        int[] bounds = receberBounds(Comunicacao.receberString(socket));

        System.out.println(nome + " >> Bounds recebidos >> " + Arrays.toString(bounds));

        multiplicaçãoDeMatrizes(bounds[0], bounds[1]);

        System.out.println(nome + ">> Multiplicação feita");

        String result = getResult(bounds[0], bounds[1]);
//          System.out.println(result);
        Comunicacao.enviar(result, socket);

        System.out.println(nome + ">> Processo enviado e finalizado.");



    }


    private void multiplicaçãoDeMatrizes(int comeco, int fim){
        int n = matrizA.getLinhas();          //  numero de linhas
        int k = matrizA.getColunas();    //  numero de coluna
        for (int x = comeco; x < fim; x++){
            int[] pos = findPoss(x);
            int linha = pos[0];
            int coluna = pos[1];
            System.out.println(x + " -> " + Arrays.toString(pos));
            matrizC.getMatriz()[linha][coluna] = 0.0;
            for (int i = 0; i < k; i++)
                matrizC.getMatriz()[linha][coluna] = matrizC.getMatriz()[linha][coluna] + matrizA.getMatriz()[linha][i] * matrizB.getMatriz()[i][coluna];
        }
    }


    private String getResult(int comeco, int fim){
        StringBuilder sb = new StringBuilder();
        for (int i = comeco; i < fim; i++){
            int [] pos = findPoss(i);
            sb.append(df.format(matrizC.getMatriz()[pos[0]][pos[1]])).append(";");
        }
        return new String(sb);
    }

    private int[] receberBounds(String stringao){
        return new int[]{Integer.parseInt(stringao.split(",")[0]), Integer.parseInt(stringao.split(",")[1])};
    }

    private int[] findPoss(int indexFull){
        int acumulador = 0;
        for (int l = 0; l < matrizA.getLinhas(); l++)
            for (int c = 0; c < matrizB.getColunas(); c++)
                if (acumulador == indexFull)
                    return new int[]{l, c};
                else
                    acumulador++;
        return null;
    }

    public void setMatriz(Matriz matrizA, Matriz matrizB) {
        this.matrizA = matrizA;
        this.matrizB = matrizB;
    }

/*

    private static void testeRapido() throws Exception{

        Calculador calculador = new Calculador("testekk", 1212);

        calculador.setMatriz(new Matriz(10,15,12,15), new Matriz(10,15,15,10));

        calculador.matrizC = new Matriz(calculador.matrizA.getLinhas(), calculador.matrizB.getColunas());

        int[] begin = new int[4];
        for (int i = 0; i < 4; i++)
            begin[i] = (i) * ((calculador.matrizC.getLinhas()*calculador.matrizC.getColunas())/4);

        int[] end = new int[4];
        for (int i = 0; i < 4; i++)
            end[i] = ((i+1) * ((calculador.matrizC.getLinhas()*calculador.matrizC.getColunas())/4))-1;

        System.out.println(0 + " >> [" + begin[0] + "," + end[0] + "]");
        calculador.multiplicaçãoDeMatrizes(begin[0], end[0]);

        calculador.matrizC.imprimirMatrix();
        System.out.println();

        System.out.println(calculador.getResult(0,10));

    }


*/


}
