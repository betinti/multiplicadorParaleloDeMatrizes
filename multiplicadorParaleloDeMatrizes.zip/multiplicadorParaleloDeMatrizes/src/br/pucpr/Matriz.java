package br.pucpr;

import java.io.*;
import java.math.*;
import java.util.*;

public class Matriz implements Serializable{

    private final Random rand = new Random();

    private double[][] matriz;
    private final int linhas;
    private final int colunas;


    public Matriz(int linhas, int colunas){
        this.linhas = linhas;
        this.colunas = colunas;

        matriz = new double[linhas][colunas];
    }

    public Matriz(double[][] matriz){

        this.matriz = matriz;

        this.linhas = matriz.length;
        this.colunas = matriz[0].length;

    }

    public Matriz (int valMin, int valMax, int linha, int coluna){

        this.matriz = gerarAleatoria(valMin, valMax, linha, coluna);

        this.linhas = matriz.length;
        this.colunas = matriz[0].length;

    }

    public Matriz(String path) throws Exception{

        this.matriz = lerArquivo(new BufferedReader(new FileReader(new File(path))));

        this.linhas = matriz.length;
        this.colunas = matriz[0].length;

    }



    public int getColunas() {
        return colunas;
    }

    public int getLinhas() {
        return linhas;
    }

    public double[][] getMatriz() {
        return matriz;
    }



    public void saveMatrix(BufferedWriter bw) throws Exception{
        bw.append(String.valueOf(linhas)).append(",").append(String.valueOf(colunas)).flush();
        bw.newLine();
        for (double[] linha: matriz){
            for (double coluna: linha)
                bw.append(String.valueOf(coluna)).append(",").flush();
            bw.newLine();
        }
        bw.close();
    }

    public void imprimirMatrix(){
        for (double[] linha : matriz)
            System.out.println(Arrays.toString(linha));
    }



    private double[][] gerarAleatoria(int valMin, int valMax, int l, int c){
        double[][] aux = new double[l][c];

        for (int i = 0; i < l; i++)
            for (int j = 0; j < c; j++)
                aux[i][j] = randDouble(valMin, valMax, 2);

        return aux;
    }

    private double randDouble(int min, int max, int places){
        int randInt = rand.nextInt(max-min)+min;
        BigDecimal bigDecimal = new BigDecimal(Double.toString(randInt + rand.nextDouble()));
        bigDecimal = bigDecimal.setScale(places, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

    private double[][] lerArquivo(BufferedReader br) throws Exception{
        int l, c;
        String[] tamanhos = br.readLine().split(",");
        l = Integer.parseInt(tamanhos[0]);
        c = Integer.parseInt(tamanhos[1]);

        double[][] matriz = new double[l][c];

        for (int i = 0; i < l; i++){
            String[] linha = br.readLine().split(",");
            for (int j = 0; j < c; j++)
                matriz[i][j] = Double.parseDouble(linha[j]);
        }
        br.close();
        return matriz;
    }




/*
    public static void main(String[] args) throws Exception{

        double[][] testeNois = {{1,2,3,4,5}, {1,2,3,4,5}, {1,2,3,4,5}, {1,2,3,4,5}, {1,2,3,4,5}};

        File fila = new File("testeMatriz.txt");
        fila.createNewFile();

        new Matriz(testeNois).saveMatrix(new BufferedWriter(new FileWriter(fila)));

        new Matriz("testeMatriz.txt").imprimirMatrix();
    }

 */

}
