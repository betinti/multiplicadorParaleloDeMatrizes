package br.pucpr.RUN;

import br.pucpr.Calculador.Calculador;
import br.pucpr.Coordenador.Coordenador;

public class Calculador_04 {

    public static void main(String[] args) throws Exception{

        new Calculador("04", Coordenador.portasCalculadorasS[3]).CALCULATE();

    }

}
