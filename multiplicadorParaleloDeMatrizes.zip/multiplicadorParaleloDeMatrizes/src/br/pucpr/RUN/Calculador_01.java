package br.pucpr.RUN;

import br.pucpr.Calculador.Calculador;
import br.pucpr.Coordenador.Coordenador;

public class Calculador_01 {

    public static void main(String[] args) throws Exception{

        new Calculador("01", Coordenador.portasCalculadorasS[0]).CALCULATE();

    }

}
