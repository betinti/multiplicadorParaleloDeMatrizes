package br.pucpr.RUN;

import br.pucpr.Calculador.Calculador;
import br.pucpr.Coordenador.Coordenador;

public class Calculador_02 {

    public static void main(String[] args) throws Exception{

        new Calculador("02", Coordenador.portasCalculadorasS[1]).CALCULATE();

    }

}
