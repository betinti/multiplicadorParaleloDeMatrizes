package br.pucpr.RUN;

import br.pucpr.Coordenador.Coordenador;

public class Coordenador_05 {

    public static void main(String[] args) throws Exception {

        new Coordenador().CALCULO();

    }

}
