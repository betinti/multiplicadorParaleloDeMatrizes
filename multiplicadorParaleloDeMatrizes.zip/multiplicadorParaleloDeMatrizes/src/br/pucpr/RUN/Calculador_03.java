package br.pucpr.RUN;

import br.pucpr.Calculador.Calculador;
import br.pucpr.Coordenador.Coordenador;

public class Calculador_03 {

    public static void main(String[] args) throws Exception{

        new Calculador("03", Coordenador.portasCalculadorasS[2]).CALCULATE();

    }

}
